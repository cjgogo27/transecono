
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import minimize

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class RamseyPricingModel:
    
    def __init__(self, marginal_cost, ramsey_number=0.3):
        self.marginal_cost = marginal_cost
        self.ramsey_number = ramsey_number
    
    def calculate_optimal_price(self, elasticity):
        abs_elasticity = abs(elasticity)
        
        if abs_elasticity < self.ramsey_number:
            print(f"警告：弹性 {abs_elasticity:.3f} 小于拉姆齐数 {self.ramsey_number}，可能导致价格过高")
            abs_elasticity = self.ramsey_number * 1.5
        
        optimal_price = self.marginal_cost / (1 - self.ramsey_number / abs_elasticity)
        
        return optimal_price
    
    def calculate_markup(self, elasticity):
        optimal_price = self.calculate_optimal_price(elasticity)
        markup = (optimal_price - self.marginal_cost) / self.marginal_cost
        return markup


def ramsey_pricing_analysis():
    
    elasticity_df = pd.read_csv('需求弹性计算结果.csv', encoding='utf-8-sig')
    
    with open('模型估计结果.json', 'r', encoding='utf-8') as f:
        model_results = json.load(f)
    
    value_of_q = model_results['value_of_Q']
    
    print("=== 拉姆齐定价模型分析 ===\n")
    
    marginal_costs = {
        '成渝高铁_老线': 108,  # 154×70%≈108元/人次
        '成渝中线_新线': 126,  # 180×70%≈126元/人次（新线设备更先进）
        '成渝高铁_一等座': 108,  # 边际成本相同，但服务质量更高
        '普速列车': 30,
        '大巴': 25
    }
    
    ramsey_scenarios = {
        '高盈利导向': 0.5,   # 较高的拉姆齐数，追求更高利润
        '平衡导向': 0.3,     # 平衡收益与社会福利
        '公益导向': 0.15    # 较低的拉姆齐数，更注重社会福利
    }
    
    pricing_results = []
    
    for scenario_name, ramsey_num in ramsey_scenarios.items():
        print(f"\n【{scenario_name}】拉姆齐数 λ = {ramsey_num}")
        print("-" * 60)
        
        for idx, row in elasticity_df.iterrows():
            transport = row['交通方式']
            mc = marginal_costs.get(transport, 50)
            elasticity = row['价格弹性']
            current_price = row['当前票价']
            q_value = row['当前Q值']
            
            ramsey_model = RamseyPricingModel(
                marginal_cost=mc,
                ramsey_number=ramsey_num
            )
            
            optimal_price = ramsey_model.calculate_optimal_price(elasticity)
            markup = ramsey_model.calculate_markup(elasticity)
            
            pricing_results.append({
                '定价情景': scenario_name,
                '交通方式': transport,
                '拉姆齐数λ': ramsey_num,
                '边际成本MC': mc,
                '需求弹性ε': elasticity,
                '当前票价': current_price,
                '最优票价': optimal_price,
                '价格调整': optimal_price - current_price,
                '调整幅度%': ((optimal_price - current_price) / current_price) * 100,
                '加成率%': markup * 100,
                'Q值': q_value,
                '市场份额%': row['市场份额'] * 100
            })
            
            print(f"{transport:20s} | MC={mc:3.0f} | ε={elasticity:6.3f} | "
                  f"当前价格={current_price:3.0f} | 最优价格={optimal_price:6.1f} | "
                  f"调整={optimal_price-current_price:+5.1f} ({((optimal_price-current_price)/current_price)*100:+5.1f}%)")
    
    pricing_df = pd.DataFrame(pricing_results)
    pricing_df.to_csv('拉姆齐定价结果.csv', index=False, encoding='utf-8-sig')
    
    print("\n\n=== 高铁产品定价建议（平衡导向）===\n")
    
    balanced_pricing = pricing_df[pricing_df['定价情景'] == '平衡导向']
    high_speed = balanced_pricing[balanced_pricing['交通方式'].str.contains('高铁')]
    
    print(high_speed[['交通方式', '当前票价', '最优票价', '调整幅度%', 'Q值']].to_string(index=False))
    
    print("\n\n=== 基于服务质量Q值的差异化定价策略 ===\n")
    
    base_row = balanced_pricing[balanced_pricing['交通方式'] == '成渝高铁_老线'].iloc[0]
    new_line_row = balanced_pricing[balanced_pricing['交通方式'] == '成渝中线_新线'].iloc[0]
    
    base_q = base_row['Q值']
    new_q = new_line_row['Q值']
    delta_q = new_q - base_q
    
    print(f"成渝高铁老线：Q值 = {base_q:.2f}, 最优票价 = {base_row['最优票价']:.0f} 元")
    print(f"成渝中线新线：Q值 = {new_q:.2f}, 最优票价 = {new_line_row['最优票价']:.0f} 元")
    print(f"\nQ值提升：{delta_q:.2f} 分")
    print(f"票价差异：{new_line_row['最优票价'] - base_row['最优票价']:.0f} 元")
    print(f"每提升1分Q值支撑的票价增量：{(new_line_row['最优票价'] - base_row['最优票价']) / delta_q:.2f} 元/分")
    print(f"（模型估计的服务质量价值：{value_of_q:.2f} 元/分）")
    
    print("\n\n=== 成渝中线高铁分层定价方案 ===\n")
    
    tiered_pricing = construct_tiered_pricing(balanced_pricing, value_of_q)
    
    return pricing_df, tiered_pricing


def construct_tiered_pricing(pricing_df, value_of_q):
    
    base_pricing = pricing_df[pricing_df['交通方式'] == '成渝中线_新线'].iloc[0]
    base_price = base_pricing['最优票价']
    base_q = base_pricing['Q值']
    
    tiers = []
    
    print("一、座席等级分层")
    print("-" * 60)
    
    seat_classes = [
        {
            '等级': '二等座',
            'Q值调整': 0,
            '舒适度': '标准',
            '服务特色': '基础座位、标准服务'
        },
        {
            '等级': '一等座',
            'Q值调整': 0.6,
            '舒适度': '舒适',
            '服务特色': '宽敞座位、免费小食、充电插座'
        },
        {
            '等级': '商务座',
            'Q值调整': 1.2,
            '舒适度': '豪华',
            '服务特色': '躺椅座位、VIP休息室、餐食、专属服务'
        },
        {
            '等级': '特等座',
            'Q值调整': 1.5,
            '舒适度': '顶级',
            '服务特色': '独立包厢、高端餐食、秘书服务、贵宾通道'
        }
    ]
    
    for seat in seat_classes:
        adjusted_q = base_q + seat['Q值调整']
        price = base_price + seat['Q值调整'] * value_of_q
        
        tier_info = {
            '分层类型': '座席等级',
            '层级名称': seat['等级'],
            'Q值': adjusted_q,
            '票价': price,
            '相对基准涨幅%': (price - base_price) / base_price * 100,
            '服务特色': seat['服务特色']
        }
        tiers.append(tier_info)
        
        print(f"{seat['等级']:8s} | Q值={adjusted_q:4.2f} | 票价={price:6.1f}元 | "
              f"涨幅={((price-base_price)/base_price)*100:5.1f}% | {seat['服务特色']}")
    
    print(f"\n二、时段需求分层（基准：二等座 {base_price:.0f}元）")
    print("-" * 60)
    
    time_periods = [
        {
            '时段': '高峰时段',
            '时间': '周一-周五 7:00-9:00, 17:00-19:00',
            'Q值调整': 0.3,  # 高峰时段班次密集，准点率高
            '需求系数': 1.15,  # 需求旺盛，价格上浮
            '特点': '通勤高峰，班次密集'
        },
        {
            '时段': '平峰时段',
            '时间': '周一-周五 其他时间',
            'Q值调整': 0,
            '需求系数': 1.0,
            '特点': '基准票价'
        },
        {
            '时段': '周末/节假日',
            '时间': '周六、周日及法定节假日',
            'Q值调整': 0.2,
            '需求系数': 1.10,
            '特点': '旅游出行，服务质量稍好'
        },
        {
            '时段': '夜间时段',
            '时间': '21:00-次日6:00',
            'Q值调整': -0.2,  # 夜间服务质量略低
            '需求系数': 0.85,  # 需求较弱，价格下调
            '特点': '需求较低，折扣优惠'
        }
    ]
    
    for period in time_periods:
        adjusted_q = base_q + period['Q值调整']
        q_price_adjustment = period['Q值调整'] * value_of_q
        demand_price_adjustment = base_price * (period['需求系数'] - 1)
        price = base_price + q_price_adjustment + demand_price_adjustment
        
        tier_info = {
            '分层类型': '时段需求',
            '层级名称': period['时段'],
            'Q值': adjusted_q,
            '票价': price,
            '相对基准涨幅%': (price - base_price) / base_price * 100,
            '服务特色': f"{period['时间']} - {period['特点']}"
        }
        tiers.append(tier_info)
        
        print(f"{period['时段']:12s} | Q值={adjusted_q:4.2f} | 票价={price:6.1f}元 | "
              f"涨幅={((price-base_price)/base_price)*100:+5.1f}% | {period['特点']}")
    
    print(f"\n三、预订时间分层（基准：二等座 {base_price:.0f}元）")
    print("-" * 60)
    
    booking_windows = [
        {
            '预订时间': '提前30天以上',
            '折扣': 0.80,
            'Q值调整': -0.1,  # 早鸟票服务相对标准
            '特点': '早鸟优惠票'
        },
        {
            '预订时间': '提前15-30天',
            '折扣': 0.90,
            'Q值调整': 0,
            '特点': '提前购票优惠'
        },
        {
            '预订时间': '提前7-15天',
            '折扣': 0.95,
            'Q值调整': 0,
            '特点': '小幅优惠'
        },
        {
            '预订时间': '提前3-7天',
            '折扣': 1.0,
            'Q值调整': 0,
            '特点': '标准票价'
        },
        {
            '预订时间': '提前1-3天',
            '折扣': 1.05,
            'Q值调整': 0.1,  # 临近出行，服务保障更好
            '特点': '临近出行加价'
        },
        {
            '预订时间': '当日购票',
            '折扣': 1.10,
            'Q值调整': 0.2,
            '特点': '当日票加价'
        }
    ]
    
    for booking in booking_windows:
        adjusted_q = base_q + booking['Q值调整']
        q_price_adjustment = booking['Q值调整'] * value_of_q
        price = (base_price + q_price_adjustment) * booking['折扣']
        
        tier_info = {
            '分层类型': '预订时间',
            '层级名称': booking['预订时间'],
            'Q值': adjusted_q,
            '票价': price,
            '相对基准涨幅%': (price - base_price) / base_price * 100,
            '服务特色': booking['特点']
        }
        tiers.append(tier_info)
        
        print(f"{booking['预订时间']:15s} | Q值={adjusted_q:4.2f} | 票价={price:6.1f}元 | "
              f"涨幅={((price-base_price)/base_price)*100:+5.1f}% | {booking['特点']}")
    
    print(f"\n四、会员/常旅客分层（基准：二等座 {base_price:.0f}元）")
    print("-" * 60)
    
    membership_tiers = [
        {
            '会员等级': '普通用户',
            '折扣': 1.0,
            'Q值调整': 0,
            '权益': '无额外权益'
        },
        {
            '会员等级': '银卡会员',
            '折扣': 0.95,
            'Q值调整': 0.1,
            '权益': '95折优惠、优先候补'
        },
        {
            '会员等级': '金卡会员',
            '折扣': 0.90,
            'Q值调整': 0.2,
            '权益': '9折优惠、专属通道、免费改签'
        },
        {
            '会员等级': '白金会员',
            '折扣': 0.85,
            'Q值调整': 0.3,
            '权益': '85折优惠、VIP休息室、免费升舱机会'
        }
    ]
    
    for member in membership_tiers:
        adjusted_q = base_q + member['Q值调整']
        q_price_adjustment = member['Q值调整'] * value_of_q
        price = (base_price + q_price_adjustment) * member['折扣']
        
        tier_info = {
            '分层类型': '会员等级',
            '层级名称': member['会员等级'],
            'Q值': adjusted_q,
            '票价': price,
            '相对基准涨幅%': (price - base_price) / base_price * 100,
            '服务特色': member['权益']
        }
        tiers.append(tier_info)
        
        print(f"{member['会员等级']:10s} | Q值={adjusted_q:4.2f} | 票价={price:6.1f}元 | "
              f"折扣={((price-base_price)/base_price)*100:+5.1f}% | {member['权益']}")
    
    tiers_df = pd.DataFrame(tiers)
    tiers_df.to_csv('分层定价方案.csv', index=False, encoding='utf-8-sig')
    
    print(f"\n\n五、综合定价矩阵示例（组合策略）")
    print("=" * 80)
    
    examples = [
        {
            '场景': '商务白金会员 + 一等座 + 高峰时段 + 当日票',
            '基础': base_price,
            '座席': 0.6 * value_of_q,
            '时段': base_price * 0.15,
            '预订': base_price * 0.10,
            '会员折扣': -base_price * 0.15
        },
        {
            '场景': '普通用户 + 二等座 + 平峰时段 + 提前30天',
            '基础': base_price,
            '座席': 0,
            '时段': 0,
            '预订': -base_price * 0.20,
            '会员折扣': 0
        },
        {
            '场景': '金卡会员 + 二等座 + 周末 + 提前15天',
            '基础': base_price,
            '座席': 0,
            '时段': base_price * 0.10,
            '预订': -base_price * 0.10,
            '会员折扣': -base_price * 0.10
        }
    ]
    
    for ex in examples:
        total_price = ex['基础'] + ex['座席'] + ex['时段'] + ex['预订'] + ex['会员折扣']
        print(f"\n{ex['场景']}")
        print(f"  基础票价: {ex['基础']:.0f}元")
        print(f"  + 座席调整: {ex['座席']:+.0f}元")
        print(f"  + 时段调整: {ex['时段']:+.0f}元")
        print(f"  + 预订调整: {ex['预订']:+.0f}元")
        print(f"  + 会员折扣: {ex['会员折扣']:+.0f}元")
        print(f"  = 最终票价: {total_price:.0f}元")
    
    print("\n" + "=" * 80)
    
    return tiers_df


def visualize_pricing_results():
    pricing_df = pd.read_csv('拉姆齐定价结果.csv', encoding='utf-8-sig')
    tiers_df = pd.read_csv('分层定价方案.csv', encoding='utf-8-sig')
    
    fig = plt.figure(figsize=(18, 12))
    gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
    
    ax1 = fig.add_subplot(gs[0, :2])
    
    high_speed_pricing = pricing_df[pricing_df['交通方式'].str.contains('高铁')]
    
    scenarios = high_speed_pricing['定价情景'].unique()
    x = np.arange(len(high_speed_pricing['交通方式'].unique()))
    width = 0.25
    
    for i, scenario in enumerate(scenarios):
        scenario_data = high_speed_pricing[high_speed_pricing['定价情景'] == scenario]
        ax1.bar(x + i*width, scenario_data['最优票价'], width, 
                label=scenario, alpha=0.8)
    
    ax1.set_xlabel('高铁类型', fontsize=11)
    ax1.set_ylabel('最优票价（元）', fontsize=11)
    ax1.set_title('不同拉姆齐数下的高铁最优定价对比', fontsize=13, fontweight='bold')
    ax1.set_xticks(x + width)
    ax1.set_xticklabels([t.replace('成渝高铁_', '').replace('成渝', '') 
                          for t in high_speed_pricing['交通方式'].unique()], 
                         rotation=0)
    ax1.legend(fontsize=10)
    ax1.grid(axis='y', alpha=0.3)
    
    ax2 = fig.add_subplot(gs[0, 2])
    
    balanced = pricing_df[pricing_df['定价情景'] == '平衡导向']
    scatter = ax2.scatter(balanced['需求弹性ε'], balanced['加成率%'],
                          s=balanced['市场份额%']*20,
                          c=balanced['Q值'], cmap='viridis',
                          alpha=0.6, edgecolors='black')
    
    ax2.set_xlabel('需求弹性', fontsize=10)
    ax2.set_ylabel('加成率 (%)', fontsize=10)
    ax2.set_title('加成率 vs 需求弹性\n（气泡大小=市场份额）', fontsize=11, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    plt.colorbar(scatter, ax=ax2, label='Q值', shrink=0.8)
    
    ax3 = fig.add_subplot(gs[1, 0])
    
    seat_tiers = tiers_df[tiers_df['分层类型'] == '座席等级']
    colors_seat = ['#3498db', '#2ecc71', '#f39c12', '#e74c3c']
    
    bars = ax3.bar(range(len(seat_tiers)), seat_tiers['票价'], 
                   color=colors_seat, alpha=0.7, edgecolor='black')
    ax3.set_xticks(range(len(seat_tiers)))
    ax3.set_xticklabels(seat_tiers['层级名称'], fontsize=9)
    ax3.set_ylabel('票价（元）', fontsize=10)
    ax3.set_title('座席等级分层定价', fontsize=11, fontweight='bold')
    ax3.grid(axis='y', alpha=0.3)
    
    for bar, price in zip(bars, seat_tiers['票价']):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height,
                f'{price:.0f}元',
                ha='center', va='bottom', fontsize=8)
    
    ax4 = fig.add_subplot(gs[1, 1])
    
    time_tiers = tiers_df[tiers_df['分层类型'] == '时段需求']
    colors_time = ['#e74c3c', '#3498db', '#f39c12', '#9b59b6']
    
    bars = ax4.bar(range(len(time_tiers)), time_tiers['票价'],
                   color=colors_time, alpha=0.7, edgecolor='black')
    ax4.set_xticks(range(len(time_tiers)))
    ax4.set_xticklabels(time_tiers['层级名称'], fontsize=9, rotation=15)
    ax4.set_ylabel('票价（元）', fontsize=10)
    ax4.set_title('时段需求分层定价', fontsize=11, fontweight='bold')
    ax4.grid(axis='y', alpha=0.3)
    
    for bar, price in zip(bars, time_tiers['票价']):
        height = bar.get_height()
        ax4.text(bar.get_x() + bar.get_width()/2., height,
                f'{price:.0f}',
                ha='center', va='bottom', fontsize=8)
    
    ax5 = fig.add_subplot(gs[1, 2])
    
    booking_tiers = tiers_df[tiers_df['分层类型'] == '预订时间']
    
    ax5.plot(range(len(booking_tiers)), booking_tiers['票价'],
             marker='o', linewidth=2.5, markersize=8, color='#2ecc71')
    ax5.fill_between(range(len(booking_tiers)), 
                      booking_tiers['票价'].min() * 0.95,
                      booking_tiers['票价'],
                      alpha=0.3, color='#2ecc71')
    ax5.set_xticks(range(len(booking_tiers)))
    ax5.set_xticklabels([t[:6] for t in booking_tiers['层级名称']], 
                         fontsize=8, rotation=30)
    ax5.set_ylabel('票价（元）', fontsize=10)
    ax5.set_title('预订时间分层定价', fontsize=11, fontweight='bold')
    ax5.grid(True, alpha=0.3)
    
    ax6 = fig.add_subplot(gs[2, 0])
    
    member_tiers = tiers_df[tiers_df['分层类型'] == '会员等级']
    colors_member = ['#95a5a6', '#95a5a6', '#f39c12', '#e8e8e8']
    
    bars = ax6.barh(range(len(member_tiers)), member_tiers['票价'],
                    color=colors_member, alpha=0.7, edgecolor='black')
    ax6.set_yticks(range(len(member_tiers)))
    ax6.set_yticklabels(member_tiers['层级名称'], fontsize=9)
    ax6.set_xlabel('票价（元）', fontsize=10)
    ax6.set_title('会员等级分层定价', fontsize=11, fontweight='bold')
    ax6.grid(axis='x', alpha=0.3)
    
    for bar, price in zip(bars, member_tiers['票价']):
        width = bar.get_width()
        ax6.text(width, bar.get_y() + bar.get_height()/2.,
                f' {price:.0f}元',
                ha='left', va='center', fontsize=8)
    
    ax7 = fig.add_subplot(gs[2, 1:])
    
    ax7.scatter(tiers_df['Q值'], tiers_df['票价'],
                c=tiers_df['分层类型'].astype('category').cat.codes,
                s=100, alpha=0.6, edgecolors='black', cmap='Set2')
    
    z = np.polyfit(tiers_df['Q值'], tiers_df['票价'], 1)
    p = np.poly1d(z)
    x_line = np.linspace(tiers_df['Q值'].min(), tiers_df['Q值'].max(), 100)
    ax7.plot(x_line, p(x_line), "r--", linewidth=2, 
             label=f'拟合线: 票价 = {z[0]:.1f} × Q值 + {z[1]:.1f}')
    
    ax7.set_xlabel('服务质量Q值', fontsize=11)
    ax7.set_ylabel('票价（元）', fontsize=11)
    ax7.set_title('服务质量Q值与票价的关系（所有分层）', fontsize=12, fontweight='bold')
    ax7.legend(fontsize=10)
    ax7.grid(True, alpha=0.3)
    
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor=plt.cm.Set2(i), label=tier_type)
                       for i, tier_type in enumerate(tiers_df['分层类型'].unique())]
    ax7.legend(handles=legend_elements, loc='lower right', fontsize=9)
    
    plt.savefig('拉姆齐定价与分层方案可视化.png', dpi=300, bbox_inches='tight')
    print("\n可视化图表已保存: 拉姆齐定价与分层方案可视化.png")


if __name__ == "__main__":
    pricing_df, tiered_pricing = ramsey_pricing_analysis()
    visualize_pricing_results()
    print("\n第五步完成！拉姆齐定价模型已应用，分层定价方案已生成。")
