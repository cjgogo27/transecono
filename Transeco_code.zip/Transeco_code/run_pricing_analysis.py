"""
主程序：运行完整的定价模型流程
从LLM分析评论到生成分层定价方案
"""

import sys
import os
from datetime import datetime

def main():
    """
    运行完整的定价分析流程
    """
    
    print("=" * 80)
    print(" " * 20 + "基于LLM和拉姆齐模型的高铁分层定价系统")
    print(" " * 30 + "成渝高铁案例分析")
    print("=" * 80)
    print(f"\n开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # 检查必要的文件
    if not os.path.exists('用户评价样本.csv'):
        print("错误：未找到 '用户评价样本.csv' 文件")
        print("请确保评论数据文件存在于当前目录")
        return
    
    try:
        # 第一步：LLM分析评论数据
        print("\n" + "=" * 80)
        print("第一步：使用LLM分析评论数据，提取服务质量指标")
        print("=" * 80)
        
        from step1_llm_analysis import process_comments
        
        print("\n正在处理评论数据...")
        result_df = process_comments('用户评价样本.csv', '用户评价_带评分.csv')
        print("✓ 第一步完成\n")
        
        input("按Enter键继续下一步...")
        
        # 第二步：构建离散选择数据集
        print("\n" + "=" * 80)
        print("第二步：构建离散选择模型的完整数据集")
        print("=" * 80)
        
        from step2_build_dataset import build_choice_dataset
        
        print("\n正在构建选择数据集...")
        choice_df = build_choice_dataset()
        print("✓ 第二步完成\n")
        
        input("按Enter键继续下一步...")
        
        # 第三步：Logit模型估计
        print("\n" + "=" * 80)
        print("第三步：建立Logit离散选择模型并进行回归分析")
        print("=" * 80)
        
        from step3_logit_model import estimate_logit_model
        
        print("\n正在估计Logit模型...")
        result1, result2, model_results = estimate_logit_model()
        print("✓ 第三步完成\n")
        
        input("按Enter键继续下一步...")
        
        # 第四步：弹性分析和服务质量货币化
        print("\n" + "=" * 80)
        print("第四步：计算需求价格弹性和服务质量的货币化")
        print("=" * 80)
        
        from step4_elasticity_analysis import monetize_service_quality
        
        print("\n正在计算需求弹性...")
        elasticity_df, scenario_df, model_results = monetize_service_quality()
        print("✓ 第四步完成\n")
        
        input("按Enter键继续下一步...")
        
        # 第五步：拉姆齐定价和分层方案
        print("\n" + "=" * 80)
        print("第五步：应用拉姆齐定价模型，生成分层定价方案")
        print("=" * 80)
        
        from step5_ramsey_pricing import ramsey_pricing_analysis, visualize_pricing_results
        
        print("\n正在应用拉姆齐定价模型...")
        pricing_df, tiered_pricing = ramsey_pricing_analysis()
        
        print("\n正在生成可视化图表...")
        visualize_pricing_results()
        
        print("✓ 第五步完成\n")
        
        # 总结
        print("\n" + "=" * 80)
        print("=" * 80)
        print(" " * 35 + "完成！")
        print("=" * 80)
        print("=" * 80)
        
        print("\n生成的文件清单：")
        print("-" * 80)
        
        output_files = [
            ('用户评价_带评分.csv', 'LLM分析后的评论数据（含Q值评分）'),
            ('离散选择数据集.csv', '离散选择模型的完整数据集'),
            ('模型估计结果.json', 'Logit模型参数估计结果'),
            ('模型系数可视化.png', 'Logit模型系数可视化图表'),
            ('需求弹性计算结果.csv', '各交通方式的需求弹性'),
            ('服务质量货币化情景分析.csv', '服务质量提升的货币价值分析'),
            ('需求弹性与服务质量货币化分析.png', '弹性分析可视化图表'),
            ('拉姆齐定价结果.csv', '基于拉姆齐模型的最优定价'),
            ('分层定价方案.csv', '完整的分层定价方案'),
            ('拉姆齐定价与分层方案可视化.png', '定价方案可视化图表')
        ]
        
        for i, (filename, description) in enumerate(output_files, 1):
            status = "✓" if os.path.exists(filename) else "✗"
            print(f"{status} {i:2d}. {filename:45s} - {description}")
        
        print("\n" + "=" * 80)
        print("核心发现总结：")
        print("-" * 80)
        
        # 读取关键结果
        import json
        import pandas as pd
        
        with open('模型估计结果.json', 'r', encoding='utf-8') as f:
            model_res = json.load(f)
        
        pricing_final = pd.read_csv('拉姆齐定价结果.csv', encoding='utf-8-sig')
        balanced = pricing_final[pricing_final['定价情景'] == '平衡导向']
        
        print(f"\n1. 服务质量(Q值)的货币价值: {model_res['value_of_Q']:.2f} 元/分")
        print(f"   → Q值每提升1分，旅客愿意多支付 {model_res['value_of_Q']:.2f} 元")
        
        print(f"\n2. 时间价值: {model_res['value_of_time']:.2f} 元/小时")
        print(f"   → 耗时每减少1小时，旅客愿意多支付 {model_res['value_of_time']:.2f} 元")
        
        # 成渝中线定价建议
        new_line = balanced[balanced['交通方式'] == '成渝中线_新线']
        if len(new_line) > 0:
            new_line = new_line.iloc[0]
            print(f"\n3. 成渝中线高铁建议定价（二等座，平衡导向）:")
            print(f"   当前预设价格: {new_line['当前票价']:.0f} 元")
            print(f"   最优票价: {new_line['最优票价']:.0f} 元")
            print(f"   调整幅度: {new_line['调整幅度%']:+.1f}%")
        
        tiers = pd.read_csv('分层定价方案.csv', encoding='utf-8-sig')
        
        print(f"\n4. 分层定价方案涵盖:")
        print(f"   • 座席等级: {len(tiers[tiers['分层类型']=='座席等级'])} 个层级")
        print(f"   • 时段需求: {len(tiers[tiers['分层类型']=='时段需求'])} 个时段")
        print(f"   • 预订时间: {len(tiers[tiers['分层类型']=='预订时间'])} 个档位")
        print(f"   • 会员等级: {len(tiers[tiers['分层类型']=='会员等级'])} 个等级")
        
        seat_tiers = tiers[tiers['分层类型'] == '座席等级']
        if len(seat_tiers) > 0:
            print(f"\n5. 座席定价范围: {seat_tiers['票价'].min():.0f} - {seat_tiers['票价'].max():.0f} 元")
            print(f"   价格差异倍数: {seat_tiers['票价'].max() / seat_tiers['票价'].min():.2f}x")
        
        print("\n" + "=" * 80)
        print("\n下一步建议：")
        print("-" * 80)
        print("1. 查看各个CSV文件了解详细数据")
        print("2. 查看PNG图表了解可视化结果")
        print("3. 根据实际情况调整参数（边际成本、拉姆齐数等）")
        print("4. 可以收集更多评论数据，使用真实的LLM API提高准确性")
        print("5. 进行敏感性分析，测试不同参数设定的影响")
        
        print("\n" + "=" * 80)
        print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80 + "\n")
        
    except Exception as e:
        print(f"\n错误：程序执行过程中发生异常")
        print(f"异常信息: {str(e)}")
        import traceback
        traceback.print_exc()
        return


if __name__ == "__main__":
    main()
