
import sys
import os
from datetime import datetime

def main():

    
    if not os.path.exists('用户评价样本.csv'):
        print("错误：未找到 '用户评价样本.csv' 文件")
        print("请确保评论数据文件存在于当前目录")
        return
    
    try:
        
        from step1_llm_analysis import process_comments
        
        result_df = process_comments('用户评价样本.csv', '用户评价_带评分.csv')
        
        input("按Enter键继续下一步...")
        
        from step2_build_dataset import build_choice_dataset
        
        choice_df = build_choice_dataset()

        
        from step3_logit_model import estimate_logit_model

        result1, result2, model_results = estimate_logit_model()

        input("按Enter键继续下一步...")
        
        from step4_elasticity_analysis import monetize_service_quality

        elasticity_df, scenario_df, model_results = monetize_service_quality()

        input("按Enter键继续下一步...")
        
        from step5_ramsey_pricing import ramsey_pricing_analysis, visualize_pricing_results
        
        pricing_df, tiered_pricing = ramsey_pricing_analysis()
        
        visualize_pricing_results()
        
        output_files = [
            ('用户评价_带评分.csv', 'LLM分析后的评论数据（含Q值评分）'),
            ('离散选择数据集.csv', '离散选择模型的完整数据集'),
            ('模型估计结果.json', 'Logit模型参数估计结果'),
            ('模型系数可视化.png', 'Logit模型系数可视化图表'),
            ('需求弹性计算结果.csv', '各交通方式的需求弹性'),
            ('服务质量货币化情景分析.csv', '服务质量提升的货币价值分析'),
            ('需求弹性与服务质量货币化分析.png', '弹性分析可视化图表'),
            ('拉姆齐定价结果.csv', '基于拉姆齐模型的最优定价'),
            ('分层定价方案.csv', '完整的分层定价方案'),
            ('拉姆齐定价与分层方案可视化.png', '定价方案可视化图表')
        ]
        
        for i, (filename, description) in enumerate(output_files, 1):
            status = "✓" if os.path.exists(filename) else "✗"
            print(f"{status} {i:2d}. {filename:45s} - {description}")

        import json
        import pandas as pd
        
        with open('模型估计结果.json', 'r', encoding='utf-8') as f:
            model_res = json.load(f)
        
        pricing_final = pd.read_csv('拉姆齐定价结果.csv', encoding='utf-8-sig')
        balanced = pricing_final[pricing_final['定价情景'] == '平衡导向']
        
        new_line = balanced[balanced['交通方式'] == '成渝中线_新线']
        if len(new_line) > 0:
            new_line = new_line.iloc[0]
        
        tiers = pd.read_csv('分层定价方案.csv', encoding='utf-8-sig')
        
    except Exception as e:
        print(f"\n错误：程序执行过程中发生异常")
        print(f"异常信息: {str(e)}")
        import traceback
        traceback.print_exc()
        return


if __name__ == "__main__":
    main()
