"""
第一步：使用LLM分析评论数据，提取服务质量指标
从舒适度、准点率、服务态度三个维度打分（1-5分），并给出综合Q值
"""

import pandas as pd
import requests
import json
import time
from typing import Dict, List

# 配置LLM API（这里使用通义千问为例，你需要替换为你的API key）
API_KEY = "your_api_key_here"  # 请替换为你的实际API key
API_URL = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"

def call_llm_api(comment: str) -> Dict:
    """
    调用LLM API分析单条评论
    
    参数:
        comment: 评论文本
    
    返回:
        包含各维度评分的字典
    """
    prompt = f"""请分析以下高铁乘客评论，从以下三个维度打分（1-5分，1分最差，5分最好）：
1. 舒适度（座位舒适性、车厢环境、平稳性等）
2. 准点率（是否准时、候车体验等）
3. 服务态度（列车员服务、售票服务等）

然后给出一个综合Q值（1-5分），这个综合值应该是三个维度的加权平均。

评论内容："{comment}"

请严格按照以下JSON格式返回（只返回JSON，不要其他说明文字）：
{{
    "舒适度": 分数,
    "准点率": 分数,
    "服务态度": 分数,
    "综合Q值": 分数,
    "评分理由": "简要说明"
}}"""

    # 方式1：使用通义千问API（需要配置API_KEY）
    if API_KEY != "your_api_key_here":
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {API_KEY}'
        }
        data = {
            "model": "qwen-plus",
            "input": {
                "messages": [
                    {"role": "user", "content": prompt}
                ]
            },
            "parameters": {
                "result_format": "message"
            }
        }
        
        try:
            response = requests.post(API_URL, headers=headers, json=data)
            result = response.json()
            content = result['output']['choices'][0]['message']['content']
            # 提取JSON部分
            start_idx = content.find('{')
            end_idx = content.rfind('}') + 1
            json_str = content[start_idx:end_idx]
            return json.loads(json_str)
        except Exception as e:
            print(f"API调用失败: {e}")
            return None
    
    # 方式2：如果没有API，使用基于规则的模拟评分（用于演示）
    else:
        return simulate_llm_scoring(comment)


def simulate_llm_scoring(comment: str) -> Dict:
    """
    模拟LLM评分（基于关键词规则，用于演示）
    实际项目中应该使用真实的LLM API
    """
    score = {
        "舒适度": 3.0,
        "准点率": 3.0, 
        "服务态度": 3.0,
        "综合Q值": 3.0,
        "评分理由": "基于关键词分析"
    }
    
    # 舒适度关键词
    comfort_positive = ["舒服", "平稳", "舒适", "座椅好", "环境好", "宽敞"]
    comfort_negative = ["窄", "挤", "硬", "不舒服", "面包屑", "脏"]
    
    # 准点率关键词
    ontime_positive = ["准时", "顺畅", "快", "很快就到"]
    ontime_negative = ["晚点", "延误", "等待"]
    
    # 服务态度关键词
    service_positive = ["服务好", "热情", "贴心", "主动帮忙", "照看", "美丽", "漂亮"]
    service_negative = ["态度差", "不耐烦", "服务差"]
    
    # 计算舒适度
    comfort_score = 3.0
    for word in comfort_positive:
        if word in comment:
            comfort_score += 0.5
    for word in comfort_negative:
        if word in comment:
            comfort_score -= 0.5
    score["舒适度"] = max(1.0, min(5.0, comfort_score))
    
    # 计算准点率
    ontime_score = 3.0
    for word in ontime_positive:
        if word in comment:
            ontime_score += 0.5
    for word in ontime_negative:
        if word in comment:
            ontime_score -= 1.0
    score["准点率"] = max(1.0, min(5.0, ontime_score))
    
    # 计算服务态度
    service_score = 3.0
    for word in service_positive:
        if word in comment:
            service_score += 0.5
    for word in service_negative:
        if word in comment:
            service_score -= 0.5
    score["服务态度"] = max(1.0, min(5.0, service_score))
    
    # 综合评分（加权平均，可以调整权重）
    score["综合Q值"] = round(
        0.35 * score["舒适度"] + 
        0.30 * score["准点率"] + 
        0.35 * score["服务态度"], 
        2
    )
    
    return score


def process_comments(input_file: str, output_file: str):
    """
    批量处理评论数据
    
    参数:
        input_file: 输入的CSV文件路径
        output_file: 输出的CSV文件路径（包含评分）
    """
    # 读取评论数据
    df = pd.read_csv(input_file, encoding='utf-8-sig')
    
    print(f"开始处理 {len(df)} 条评论...")
    
    # 存储评分结果
    scores = []
    
    for idx, row in df.iterrows():
        print(f"处理第 {idx + 1}/{len(df)} 条评论...")
        comment = row['具体评价']
        
        # 调用LLM API
        score = call_llm_api(comment)
        
        if score:
            scores.append(score)
            print(f"  舒适度: {score['舒适度']}, 准点率: {score['准点率']}, "
                  f"服务态度: {score['服务态度']}, 综合Q值: {score['综合Q值']}")
        else:
            # 如果API调用失败，使用默认值
            scores.append({
                "舒适度": 3.0,
                "准点率": 3.0,
                "服务态度": 3.0,
                "综合Q值": 3.0,
                "评分理由": "API调用失败"
            })
        
        # 避免API请求过快
        time.sleep(0.5)
    
    # 将评分结果添加到数据框
    score_df = pd.DataFrame(scores)
    result_df = pd.concat([df, score_df], axis=1)
    
    # 保存结果
    result_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"\n处理完成！结果已保存到: {output_file}")
    
    # 打印统计信息
    print("\n=== 评分统计 ===")
    print(f"舒适度平均分: {score_df['舒适度'].mean():.2f}")
    print(f"准点率平均分: {score_df['准点率'].mean():.2f}")
    print(f"服务态度平均分: {score_df['服务态度'].mean():.2f}")
    print(f"综合Q值平均分: {score_df['综合Q值'].mean():.2f}")
    
    return result_df


if __name__ == "__main__":
    # 输入输出文件路径
    input_file = "用户评价样本.csv"
    output_file = "用户评价_带评分.csv"
    
    # 处理评论
    result_df = process_comments(input_file, output_file)
    
    print("\n第一步完成！现在你有了每条评论的Q值评分。")
