
import pandas as pd
import requests
import json
import time
from typing import Dict, List

API_KEY = "your_api_key_here"  # 这里换成实际API key
API_URL = "https://api.siliconflow.cn/v1" #用的是硅基流动的API，如果没有API也可以用普通模式

def call_llm_api(comment: str) -> Dict:

    prompt = f"""请分析以下高铁乘客评论，从以下三个维度打分（1-5分，1分最差，5分最好）：
1. 舒适度（座位舒适性、车厢环境、平稳性等）
2. 准点率（是否准时、候车体验等）
3. 服务态度（列车员服务、售票服务等）

然后给出一个综合Q值（1-5分），这个综合值应该是三个维度的加权平均。

评论内容："{comment}"

请严格按照以下JSON格式返回（只返回JSON，不要其他说明文字）：
{{
    "舒适度": 分数,
    "准点率": 分数,
    "服务态度": 分数,
    "综合Q值": 分数,
    "评分理由": "简要说明"
}}"""

    if API_KEY != "your_api_key_here":
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {API_KEY}'
        }
        data = {
            "model": "Qwen/Qwen3-VL-30B-A3B-Instruct",
            "input": {
                "messages": [
                    {"role": "user", "content": prompt}
                ]
            },
            "parameters": {
                "result_format": "message"
            }
        }
        
        try:
            response = requests.post(API_URL, headers=headers, json=data)
            result = response.json()
            content = result['output']['choices'][0]['message']['content']
            start_idx = content.find('{')
            end_idx = content.rfind('}') + 1
            json_str = content[start_idx:end_idx]
            return json.loads(json_str)
        except Exception as e:
            print(f"API调用失败: {e}")
            return None

    else:
        return simulate_llm_scoring(comment)


def simulate_llm_scoring(comment: str) -> Dict:
    score = {
        "舒适度": 3.0,
        "准点率": 3.0, 
        "服务态度": 3.0,
        "综合Q值": 3.0,
        "评分理由": "基于关键词分析"
    }
    
    comfort_positive = ["舒服", "平稳", "舒适", "座椅好", "环境好", "宽敞"]
    comfort_negative = ["窄", "挤", "硬", "不舒服", "面包屑", "脏"]
    
    ontime_positive = ["准时", "顺畅", "快", "很快就到"]
    ontime_negative = ["晚点", "延误", "等待"]
    
    service_positive = ["服务好", "热情", "贴心", "主动帮忙", "照看", "美丽", "漂亮"]
    service_negative = ["态度差", "不耐烦", "服务差"]
    
    comfort_score = 3.0
    for word in comfort_positive:
        if word in comment:
            comfort_score += 0.5
    for word in comfort_negative:
        if word in comment:
            comfort_score -= 0.5
    score["舒适度"] = max(1.0, min(5.0, comfort_score))
    
    ontime_score = 3.0
    for word in ontime_positive:
        if word in comment:
            ontime_score += 0.5
    for word in ontime_negative:
        if word in comment:
            ontime_score -= 1.0
    score["准点率"] = max(1.0, min(5.0, ontime_score))
    
    service_score = 3.0
    for word in service_positive:
        if word in comment:
            service_score += 0.5
    for word in service_negative:
        if word in comment:
            service_score -= 0.5
    score["服务态度"] = max(1.0, min(5.0, service_score))
    
    score["综合Q值"] = round(
        0.35 * score["舒适度"] + 
        0.30 * score["准点率"] + 
        0.35 * score["服务态度"], 
        2
    )
    
    return score


def process_comments(input_file: str, output_file: str):

    df = pd.read_csv(input_file, encoding='utf-8-sig')
    
    print(f"开始处理 {len(df)} 条评论...")
    
    scores = []
    
    for idx, row in df.iterrows():
        print(f"处理第 {idx + 1}/{len(df)} 条评论...")
        comment = row['具体评价']

        score = call_llm_api(comment)
        
        if score:
            scores.append(score)
            print(f"  舒适度: {score['舒适度']}, 准点率: {score['准点率']}, "
                  f"服务态度: {score['服务态度']}, 综合Q值: {score['综合Q值']}")
        else:
            scores.append({
                "舒适度": 3.0,
                "准点率": 3.0,
                "服务态度": 3.0,
                "综合Q值": 3.0,
                "评分理由": "API调用失败"
            })
        
        time.sleep(0.5)
    
    score_df = pd.DataFrame(scores)
    result_df = pd.concat([df, score_df], axis=1)
    
    result_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"\n处理完成！结果已保存到: {output_file}")    
    return result_df


if __name__ == "__main__":
    input_file = "用户评价样本.csv"
    output_file = "用户评价_带评分.csv"
    
    result_df = process_comments(input_file, output_file)
    
