

import pandas as pd
import numpy as np

def build_improved_dataset():
    
    comments_df = pd.read_csv("用户评价_带评分.csv", encoding='utf-8-sig')
    

    base_q = comments_df['综合Q值'].mean()

    seat_options = {
        "成渝高铁_二等座": {
            "票价": 154,
            "耗时": 1.5,
            "Q值": base_q,  
            "座席类型": "二等座"
        },
        "成渝高铁_一等座": {
            "票价": 247,
            "耗时": 1.5,
            "Q值": base_q + 0.5, 
            "座席类型": "一等座"
        },
        "成渝高铁_商务座": {
            "票价": 464,
            "耗时": 1.5,
            "Q值": base_q + 1.0, 
            "座席类型": "商务座"
        }
    }

    new_line_options = {
        "成渝中线_二等座": {
            "票价": 140,  
            "耗时": 1.0,  
            "Q值": base_q + 0.3,  
            "座席类型": "二等座"
        },
        "成渝中线_一等座": {
            "票价": 224,
            "耗时": 1.0,
            "Q值": base_q + 0.8,
            "座席类型": "一等座"
        },
        "成渝中线_商务座": {
            "票价": 420,
            "耗时": 1.0,
            "Q值": base_q + 1.3,
            "座席类型": "商务座"
        }
    }
    
    all_options = {**seat_options, **new_line_options}
    
    choice_data = []
    individual_id = 1
    
    for idx, comment_row in comments_df.iterrows():
        scenario = comment_row['出行场景']
        comment_q = comment_row['综合Q值']
        
        for sample in range(20):
            
            for option_name, attrs in all_options.items():
                
                if scenario == "商务通勤":
                    time_value = np.random.normal(100, 20)  
                elif scenario in ["双城探亲", "双城恋爱通勤"]:
                    time_value = np.random.normal(60, 15)
                else:
                    time_value = np.random.normal(40, 10)
                
                time_value = max(20, time_value)
                
        
                generalized_cost = attrs["票价"] + time_value * attrs["耗时"]
                
                adjusted_q = attrs["Q值"] + np.random.normal(0, 0.2)
                
                utility = -0.01 * attrs["票价"] - 0.3 * attrs["耗时"] + 1.0 * adjusted_q
                

                choice_data.append({
                    "旅客ID": individual_id,
                    "出行场景": scenario,
                    "选项": option_name,
                    "线路": "成渝中线" if "中线" in option_name else "成渝老线",
                    "座席类型": attrs["座席类型"],
                    "票价P": attrs["票价"],
                    "耗时T": attrs["耗时"],
                    "Q值": adjusted_q,
                    "时间价值": time_value,
                    "广义成本": generalized_cost,
                    "效用": utility,
                    "是否选择Y": 0  # 稍后确定
                })
            
            individual_id += 1
    
    choice_df = pd.DataFrame(choice_data)
    
    for pid in choice_df['旅客ID'].unique():
        person_data = choice_df[choice_df['旅客ID'] == pid]
        max_utility_idx = person_data['效用'].idxmax()
        choice_df.loc[max_utility_idx, '是否选择Y'] = 1
    
    choice_df.to_csv("改进版_离散选择数据集.csv", index=False, encoding='utf-8-sig')
   
    seat_summary = choice_df[choice_df['是否选择Y'] == 1]['座席类型'].value_counts(normalize=True)
    print(seat_summary)
    
    print(f"\n=== 数据集统计 ===")
    stats = choice_df.groupby('选项')[['票价P', '耗时T', 'Q值', '广义成本']].mean()
    print(stats)
    
    return choice_df


if __name__ == "__main__":
    choice_df = build_improved_dataset()
