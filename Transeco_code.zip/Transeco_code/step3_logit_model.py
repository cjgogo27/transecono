"""
第三步：建立Logit离散选择模型并进行回归分析
使用多项Logit模型（Multinomial Logit Model）估计参数
"""

import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.discrete.discrete_model import MNLogit
import matplotlib.pyplot as plt
import seaborn as sns

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def estimate_logit_model():
    """
    估计多项Logit模型
    
    模型形式：P(i) = exp(V_i) / Σ exp(V_j)
    其中：V_i = β_P * 票价 + β_T * 耗时 + β_Q * Q值
    或者使用广义成本：V_i = β_GC * 广义成本 + β_Q * Q值
    """
    
    # 读取数据
    df = pd.read_csv("离散选择数据集.csv", encoding='utf-8-sig')
    
    print("=== 离散选择模型估计 ===\n")
    
    # 方法1：使用广义成本 + Q值
    print("模型1：基于广义成本和服务质量Q值")
    print("效用函数: V = β_GC * 广义成本 + β_Q * Q值\n")
    
    # 准备数据
    # 需要将数据转换为wide format，每行是一个旅客，列是各选项的属性
    
    # 这里使用替代方法：条件Logit模型
    # 我们使用简化的方法：将选择问题转换为二元选择（选或不选）
    
    # 为了使用标准的Logit回归，我们创建效用差值
    # 对于每个个体，计算其选择的方案vs其他方案的效用差
    
    # 首先，让我们使用一个简化的二项Logit来理解参数
    # 将问题简化为：是否选择高铁（vs 其他方式）
    
    df['是否高铁'] = df['交通方式'].apply(
        lambda x: 1 if '高铁' in x else 0
    )
    
    # 对于每个旅客，选择他们的实际选择记录
    actual_choices = df[df['是否选择Y'] == 1].copy()
    
    # 二项Logit回归：是否选择高铁
    X = actual_choices[['票价P', '耗时T', '综合Q值']]
    y = actual_choices['是否高铁']
    
    # 标准化变量（便于解释系数）
    X_scaled = (X - X.mean()) / X.std()
    X_scaled = sm.add_constant(X_scaled)
    
    # 拟合Logit模型
    logit_model = sm.Logit(y, X_scaled)
    result = logit_model.fit(disp=0)
    
    print("二项Logit模型结果（是否选择高铁）：")
    print(result.summary())
    print("\n")
    
    # 提取原始尺度的系数（近似）
    coef_original_scale = result.params[1:] / X.std()
    
    print("=== 模型参数解释 ===")
    print(f"β_P (票价系数): {coef_original_scale['票价P']:.4f}")
    print(f"β_T (耗时系数): {coef_original_scale['耗时T']:.4f}")
    print(f"β_Q (Q值系数): {coef_original_scale['综合Q值']:.4f}")
    
    # 计算服务质量的货币价值
    if abs(coef_original_scale['票价P']) > 0.001:
        value_of_Q = -coef_original_scale['综合Q值'] / coef_original_scale['票价P']
        print(f"\n服务质量Q值的货币价值: {value_of_Q:.2f} 元/分")
        print(f"即Q值每提高1分，旅客愿意多支付 {value_of_Q:.2f} 元")
        
        value_of_time = -coef_original_scale['耗时T'] / coef_original_scale['票价P']
        print(f"\n时间价值: {value_of_time:.2f} 元/小时")
    
    # 保存模型结果
    model_results = {
        'β_P': coef_original_scale['票价P'],
        'β_T': coef_original_scale['耗时T'],
        'β_Q': coef_original_scale['综合Q值'],
        'value_of_Q': value_of_Q,
        'value_of_time': value_of_time,
        'log_likelihood': result.llf,
        'pseudo_R2': result.prsquared
    }
    
    # 保存为JSON
    import json
    with open('模型估计结果.json', 'w', encoding='utf-8') as f:
        json.dump(model_results, f, indent=2, ensure_ascii=False)
    
    # 方法2：更精细的混合Logit模型（考虑个体异质性）
    print("\n\n=== 方法2：条件Logit模型（Choice-specific attributes）===\n")
    
    # 使用更严谨的条件Logit模型
    # 这需要mlogit格式的数据
    
    # 为每个选择集构建效用函数
    # V_ij = ASC_j + β_P * Price_j + β_T * Time_j + β_Q * Q_j
    
    # 创建替代方案特定常数（ASC）
    df['ASC'] = 1
    
    # 按旅客ID分组，对每个选择集进行建模
    # 这里我们使用简化方法：对比基准方案（大巴）
    
    # 将大巴设为基准（reference level）
    df['relative_utility'] = 0
    
    # 对于每个旅客，计算相对于大巴的效用
    for pid in df['旅客ID'].unique():
        person_data = df[df['旅客ID'] == pid]
        bus_data = person_data[person_data['交通方式'] == '大巴']
        
        if len(bus_data) > 0:
            bus_price = bus_data['票价P'].iloc[0]
            bus_time = bus_data['耗时T'].iloc[0]
            bus_q = bus_data['综合Q值'].iloc[0]
            
            df.loc[df['旅客ID'] == pid, 'relative_price'] = \
                df.loc[df['旅客ID'] == pid, '票价P'] - bus_price
            df.loc[df['旅客ID'] == pid, 'relative_time'] = \
                df.loc[df['旅客ID'] == pid, '耗时T'] - bus_time
            df.loc[df['旅客ID'] == pid, 'relative_Q'] = \
                df.loc[df['旅客ID'] == pid, '综合Q值'] - bus_q
    
    # 去除大巴的观测（作为基准）
    df_no_bus = df[df['交通方式'] != '大巴'].copy()
    
    # Logit回归（相对于基准）
    X2 = df_no_bus[['relative_price', 'relative_time', 'relative_Q']]
    y2 = df_no_bus['是否选择Y']
    
    X2 = sm.add_constant(X2)
    logit_model2 = sm.Logit(y2, X2)
    result2 = logit_model2.fit(disp=0)
    
    print("条件Logit模型结果（相对于大巴基准）：")
    print(result2.summary())
    
    # 可视化系数
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # 图1：系数可视化
    coef_names = ['票价P', '耗时T', 'Q值']
    coef_values = [coef_original_scale['票价P'], 
                   coef_original_scale['耗时T'], 
                   coef_original_scale['综合Q值']]
    
    axes[0].barh(coef_names, coef_values, color=['#e74c3c', '#3498db', '#2ecc71'])
    axes[0].set_xlabel('系数值', fontsize=12)
    axes[0].set_title('Logit模型系数', fontsize=14, fontweight='bold')
    axes[0].axvline(x=0, color='black', linestyle='--', linewidth=0.8)
    axes[0].grid(axis='x', alpha=0.3)
    
    # 图2：边际效用可视化
    marginal_effects = {
        '票价降低10元': abs(coef_original_scale['票价P']) * 10,
        '耗时减少0.5小时': abs(coef_original_scale['耗时T']) * 0.5,
        'Q值提高1分': abs(coef_original_scale['综合Q值']) * 1
    }
    
    axes[1].bar(marginal_effects.keys(), marginal_effects.values(), 
                color=['#e74c3c', '#3498db', '#2ecc71'], alpha=0.7)
    axes[1].set_ylabel('效用增量', fontsize=12)
    axes[1].set_title('边际效用对比', fontsize=14, fontweight='bold')
    axes[1].tick_params(axis='x', rotation=15)
    axes[1].grid(axis='y', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('模型系数可视化.png', dpi=300, bbox_inches='tight')
    print("\n可视化图表已保存: 模型系数可视化.png")
    
    return result, result2, model_results


if __name__ == "__main__":
    result, result2, model_results = estimate_logit_model()
    print("\n第三步完成！Logit模型已估计，参数已保存。")
