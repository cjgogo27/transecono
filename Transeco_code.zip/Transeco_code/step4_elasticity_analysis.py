
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
import seaborn as sns

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def calculate_elasticity(beta_p, beta_t, beta_q, price, time, q_value, market_share):
    own_price_elasticity = beta_p * price * (1 - market_share)
    
    time_elasticity = beta_t * time * (1 - market_share)
    
    q_elasticity = beta_q * q_value * (1 - market_share)
    
    return {
        'price_elasticity': own_price_elasticity,
        'time_elasticity': time_elasticity,
        'q_elasticity': q_elasticity
    }


def monetize_service_quality():
    
    with open('模型估计结果.json', 'r', encoding='utf-8') as f:
        model_results = json.load(f)
    
    beta_p = model_results['β_P']
    beta_t = model_results['β_T']
    beta_q = model_results['β_Q']
    value_of_q = model_results['value_of_Q']
    value_of_time = model_results['value_of_time']
    
    df = pd.read_csv("离散选择数据集.csv", encoding='utf-8-sig')
    
    actual_choices = df[df['是否选择Y'] == 1]
    market_shares = actual_choices['交通方式'].value_counts(normalize=True)
    
    print("=== 需求弹性计算 ===\n")
    
    elasticity_results = []
    
    for transport in df['交通方式'].unique():
        transport_data = df[df['交通方式'] == transport].iloc[0]
        market_share = market_shares.get(transport, 0.01)  # 避免除以0
        
        elasticities = calculate_elasticity(
            beta_p=beta_p,
            beta_t=beta_t,
            beta_q=beta_q,
            price=transport_data['票价P'],
            time=transport_data['耗时T'],
            q_value=transport_data['综合Q值'],
            market_share=market_share
        )
        
        elasticity_results.append({
            '交通方式': transport,
            '当前票价': transport_data['票价P'],
            '当前耗时': transport_data['耗时T'],
            '当前Q值': transport_data['综合Q值'],
            '市场份额': market_share,
            '价格弹性': elasticities['price_elasticity'],
            '时间弹性': elasticities['time_elasticity'],
            'Q值弹性': elasticities['q_elasticity']
        })
    
    elasticity_df = pd.DataFrame(elasticity_results)
    elasticity_df = elasticity_df.sort_values('市场份额', ascending=False)
    
    print(elasticity_df.to_string(index=False))
    print("\n")
    
    elasticity_df.to_csv('需求弹性计算结果.csv', index=False, encoding='utf-8-sig')
    
    print("=== 服务质量货币化分析 ===\n")
    
    scenarios = []
    
    base_q = df[df['交通方式'] == '成渝高铁_老线']['综合Q值'].iloc[0]
    base_price = df[df['交通方式'] == '成渝高铁_老线']['票价P'].iloc[0]
    
    print(f"基准情景（成渝高铁老线）：")
    print(f"  Q值: {base_q:.2f}")
    print(f"  票价: {base_price:.0f} 元")
    print(f"  服务质量货币价值: {value_of_q:.2f} 元/分\n")
    
    q_improvements = [0.3, 0.5, 0.8, 1.0, 1.2, 1.5]
    
    for delta_q in q_improvements:
        price_premium = delta_q * value_of_q
        
        new_price = base_price + price_premium
        
        scenarios.append({
            'Q值提升': delta_q,
            '新Q值': base_q + delta_q,
            '支撑的票价': new_price,
            '票价涨幅': price_premium,
            '涨幅比例': (price_premium / base_price) * 100
        })
        
        print(f"情景 {len(scenarios)}：Q值提升 {delta_q:.1f} 分")
        print(f"  → 新Q值: {base_q + delta_q:.2f}")
        print(f"  → 可支撑票价: {new_price:.0f} 元")
        print(f"  → 票价涨幅: {price_premium:.0f} 元 ({(price_premium/base_price)*100:.1f}%)")
        print()
    
    scenario_df = pd.DataFrame(scenarios)
    scenario_df.to_csv('服务质量货币化情景分析.csv', index=False, encoding='utf-8-sig')
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    ax1 = axes[0, 0]
    elasticity_plot = elasticity_df.sort_values('价格弹性')
    ax1.barh(elasticity_plot['交通方式'], elasticity_plot['价格弹性'], 
             color='#3498db', alpha=0.7)
    ax1.set_xlabel('价格弹性', fontsize=11)
    ax1.set_title('各交通方式的需求价格弹性', fontsize=13, fontweight='bold')
    ax1.axvline(x=0, color='red', linestyle='--', linewidth=1)
    ax1.grid(axis='x', alpha=0.3)
    
    ax2 = axes[0, 1]
    ax2.plot(scenario_df['Q值提升'], scenario_df['票价涨幅'], 
             marker='o', linewidth=2.5, markersize=8, color='#2ecc71')
    ax2.fill_between(scenario_df['Q值提升'], 0, scenario_df['票价涨幅'], 
                      alpha=0.3, color='#2ecc71')
    ax2.set_xlabel('Q值提升（分）', fontsize=11)
    ax2.set_ylabel('支撑的票价涨幅（元）', fontsize=11)
    ax2.set_title(f'服务质量货币价值\n（{value_of_q:.2f} 元/分）', 
                  fontsize=13, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    
    ax3 = axes[1, 0]
    scatter = ax3.scatter(elasticity_df['市场份额'], 
                          elasticity_df['价格弹性'],
                          s=elasticity_df['当前票价']*2,
                          c=elasticity_df['当前Q值'],
                          cmap='RdYlGn', alpha=0.6, edgecolors='black')
    
    for idx, row in elasticity_df.iterrows():
        ax3.annotate(row['交通方式'].replace('成渝', '').replace('高铁_', ''), 
                     (row['市场份额'], row['价格弹性']),
                     fontsize=8, ha='center')
    
    ax3.set_xlabel('市场份额', fontsize=11)
    ax3.set_ylabel('价格弹性', fontsize=11)
    ax3.set_title('市场份额 vs 价格弹性\n（气泡大小=票价，颜色=Q值）', 
                  fontsize=13, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    plt.colorbar(scatter, ax=ax3, label='Q值')
    
    ax4 = axes[1, 1]
    x_pos = np.arange(len(scenario_df))
    bars = ax4.bar(x_pos, scenario_df['支撑的票价'], 
                   color='#9b59b6', alpha=0.7, edgecolor='black')
    ax4.axhline(y=base_price, color='red', linestyle='--', 
                linewidth=2, label=f'基准票价 ({base_price:.0f}元)')
    ax4.set_xticks(x_pos)
    ax4.set_xticklabels([f'+{q:.1f}' for q in scenario_df['Q值提升']], 
                         fontsize=10)
    ax4.set_xlabel('Q值提升（分）', fontsize=11)
    ax4.set_ylabel('支撑的票价（元）', fontsize=11)
    ax4.set_title('Q值提升对应的定价空间', fontsize=13, fontweight='bold')
    ax4.legend(fontsize=10)
    ax4.grid(axis='y', alpha=0.3)
    
    for i, (bar, row) in enumerate(zip(bars, scenario_df.itertuples())):
        height = bar.get_height()
        ax4.text(bar.get_x() + bar.get_width()/2., height,
                f'+{row.涨幅比例:.1f}%',
                ha='center', va='bottom', fontsize=9, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('需求弹性与服务质量货币化分析.png', dpi=300, bbox_inches='tight')
    print("\n可视化图表已保存: 需求弹性与服务质量货币化分析.png")
    
    return elasticity_df, scenario_df, model_results


if __name__ == "__main__":
    elasticity_df, scenario_df, model_results = monetize_service_quality()
    print("\n第四步完成！需求弹性已计算，服务质量已货币化。")
