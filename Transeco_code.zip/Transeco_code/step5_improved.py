
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class ImprovedRamseyPricing:
    
    def __init__(self, marginal_cost, ramsey_number=0.3):
        self.marginal_cost = marginal_cost
        self.ramsey_number = ramsey_number
        self.lambda_value = ramsey_number
    
    def calculate_price_elasticity(self, beta_p, price, market_share):
        elasticity = beta_p * price * (1 - market_share)
        return elasticity
    
    def calculate_optimal_price(self, elasticity):
        abs_elasticity = abs(elasticity)
        
        if abs_elasticity < abs(self.lambda_value) * 1.2:
            print(f"  警告：弹性 {abs_elasticity:.3f} 过小，调整为 {abs(self.lambda_value * 1.5):.3f}")
            abs_elasticity = abs(self.lambda_value * 1.5)
        
        optimal_price = self.marginal_cost / (1 - self.lambda_value / abs_elasticity)
        
        markup = (optimal_price - self.marginal_cost) / self.marginal_cost
        
        return optimal_price, markup


def improved_ramsey_pricing():
    
    with open('改进版_模型估计结果.json', 'r', encoding='utf-8') as f:
        model_results = json.load(f)
    
    beta_p = model_results['β_P']
    beta_q = model_results['β_Q']
    value_of_q = model_results['value_of_Q']
    
    print("=== 拉姆齐定价模型应用 ===\n")
    print(f"模型参数：")
    print(f"  β_P = {beta_p:.4f}")
    print(f"  β_Q = {beta_q:.4f}")
    print(f"  Q值货币价值 = {value_of_q:.2f} 元/分")
    print()
    
    marginal_costs = {
        "成渝高铁_二等座": 108,  # 154×70%
        "成渝高铁_一等座": 108,
        "成渝高铁_商务座": 108,
        "成渝中线_二等座": 126,  # 180×70%=126（文献标准）
        "成渝中线_一等座": 126,
        "成渝中线_商务座": 126,
    }
    
    market_shares = {
        "成渝高铁_二等座": 0.70,
        "成渝高铁_一等座": 0.20,
        "成渝高铁_商务座": 0.05,
        "成渝中线_二等座": 0.03,
        "成渝中线_一等座": 0.015,
        "成渝中线_商务座": 0.005,
    }
    
    comments_df = pd.read_csv("用户评价_带评分.csv", encoding='utf-8-sig')
    base_q = comments_df['综合Q值'].mean()
    
    q_values = {
        "成渝高铁_二等座": base_q,
        "成渝高铁_一等座": base_q + 0.5,
        "成渝高铁_商务座": base_q + 1.0,
        "成渝中线_二等座": base_q + 0.3,
        "成渝中线_一等座": base_q + 0.8,
        "成渝中线_商务座": base_q + 1.3,
    }
    
    current_prices = {
        "成渝高铁_二等座": 154,
        "成渝高铁_一等座": 247,
        "成渝高铁_商务座": 464,
        "成渝中线_二等座": 140,  # 待定价
        "成渝中线_一等座": 224,
        "成渝中线_商务座": 420,
    }
    
    ramsey_scenarios = {
        "高盈利导向": 0.45,
        "平衡导向": 0.35,
        "公益导向": 0.25
    }
    
    all_results = []
    
    for scenario_name, ramsey_num in ramsey_scenarios.items():
        print(f"\n{'='*70}")
        print(f"【{scenario_name}】拉姆齐数 λ = {ramsey_num}")
        print('='*70)
        
        for option_name, mc in marginal_costs.items():
            current_price = current_prices[option_name]
            q_value = q_values[option_name]
            market_share = market_shares.get(option_name, 0.05)
            
            ramsey_model = ImprovedRamseyPricing(mc, ramsey_num)
            
            elasticity = ramsey_model.calculate_price_elasticity(
                beta_p, current_price, market_share
            )
            
            optimal_price, markup = ramsey_model.calculate_optimal_price(elasticity)
            
            all_results.append({
                '定价情景': scenario_name,
                '选项': option_name,
                '线路': '成渝中线' if '中线' in option_name else '成渝老线',
                '座席': option_name.split('_')[1],
                '拉姆齐数λ': ramsey_num,
                '边际成本MC': mc,
                'Q值': q_value,
                '市场份额': market_share,
                '需求弹性ε': elasticity,
                '当前票价': current_price,
                '最优票价': optimal_price,
                '价格调整': optimal_price - current_price,
                '调整幅度%': ((optimal_price - current_price) / current_price) * 100,
                '加成率%': markup * 100
            })
            
            print(f"{option_name:20s} | MC={mc:3.0f} | Q={q_value:4.2f} | "
                  f"ε={elasticity:7.3f} | 当前={current_price:3.0f} | "
                  f"最优={optimal_price:6.1f} | 调整={optimal_price-current_price:+6.1f} "
                  f"({((optimal_price-current_price)/current_price)*100:+5.1f}%)")
    
    results_df = pd.DataFrame(all_results)
    results_df.to_csv('改进版_拉姆齐定价结果.csv', index=False, encoding='utf-8-sig')
    
    print(f"\n\n{'='*70}")
    print("重点分析：成渝中线高铁定价建议（平衡导向）")
    print('='*70)
    
    balanced = results_df[results_df['定价情景'] == '平衡导向']
    new_line = balanced[balanced['线路'] == '成渝中线']
    
    print(new_line[['选项', 'Q值', '当前票价', '最优票价', '调整幅度%']].to_string(index=False))
    
    print(f"\n\n{'='*70}")
    print("分层定价方案（仅座席和时段）")
    print('='*70)
    
    tiered_pricing = construct_tiered_pricing(balanced, value_of_q, base_q)
    
    visualize_results(results_df, tiered_pricing)
    
    return results_df, tiered_pricing


def construct_tiered_pricing(pricing_df, value_of_q, base_q):
    
    tiers = []
    
    base_pricing = pricing_df[pricing_df['选项'] == '成渝中线_二等座'].iloc[0]
    base_price = base_pricing['最优票价']
    
    print(f"\n一、座席等级分层（基于服务质量Q值差异）")
    print("-" * 70)
    
    seat_classes = [
        {"等级": "二等座", "Q值调整": 0, "服务特色": "标准座位、基础服务"},
        {"等级": "一等座", "Q值调整": 0.5, "服务特色": "宽敞座位、充电插座、免费小食"},
        {"等级": "商务座", "Q值调整": 1.0, "服务特色": "躺椅、独立空间、高端餐食、VIP服务"},
    ]
    
    for seat in seat_classes:
        adjusted_q = base_q + seat["Q值调整"]
        price = base_price + seat["Q值调整"] * value_of_q
        
        tier_info = {
            '分层类型': '座席等级',
            '层级名称': seat['等级'],
            'Q值': adjusted_q,
            '票价': price,
            '相对基准涨幅%': (price - base_price) / base_price * 100,
            '服务特色': seat['服务特色']
        }
        tiers.append(tier_info)
        
        print(f"{seat['等级']:8s} | Q值={adjusted_q:4.2f} | 票价={price:6.1f}元 | "
              f"涨幅={((price-base_price)/base_price)*100:+5.1f}% | {seat['服务特色']}")
    
    print(f"\n二、时段需求分层（基于需求强度）")
    print("-" * 70)
    
    time_periods = [
        {"时段": "高峰时段", "时间": "工作日 7:00-9:00, 17:00-19:00", 
         "Q值调整": 0.2, "需求系数": 1.15, "特点": "通勤高峰"},
        {"时段": "平峰时段", "时间": "工作日 其他时间",
         "Q值调整": 0, "需求系数": 1.0, "特点": "基准票价"},
        {"时段": "周末节假日", "时间": "周六日及法定节假日",
         "Q值调整": 0.15, "需求系数": 1.10, "特点": "旅游出行"},
    ]
    
    for period in time_periods:
        adjusted_q = base_q + period["Q值调整"]
        q_adjustment = period["Q值调整"] * value_of_q
        demand_adjustment = base_price * (period["需求系数"] - 1)
        price = base_price + q_adjustment + demand_adjustment
        
        tier_info = {
            '分层类型': '时段需求',
            '层级名称': period['时段'],
            'Q值': adjusted_q,
            '票价': price,
            '相对基准涨幅%': (price - base_price) / base_price * 100,
            '服务特色': f"{period['时间']} - {period['特点']}"
        }
        tiers.append(tier_info)
        
        print(f"{period['时段']:12s} | Q值={adjusted_q:4.2f} | 票价={price:6.1f}元 | "
              f"涨幅={((price-base_price)/base_price)*100:+5.1f}% | {period['特点']}")
    
    tiers_df = pd.DataFrame(tiers)
    tiers_df.to_csv('改进版_分层定价方案.csv', index=False, encoding='utf-8-sig')
    
    print(f"\n分层定价方案已保存。")
    
    return tiers_df


def visualize_results(results_df, tiered_pricing):
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    ax1 = axes[0, 0]
    
    new_line_data = results_df[results_df['线路'] == '成渝中线']
    scenarios = new_line_data['定价情景'].unique()
    seats = ['二等座', '一等座', '商务座']
    
    x = np.arange(len(seats))
    width = 0.25
    
    for i, scenario in enumerate(scenarios):
        scenario_data = new_line_data[new_line_data['定价情景'] == scenario]
        prices = [scenario_data[scenario_data['座席'] == seat]['最优票价'].values[0] 
                 for seat in seats]
        ax1.bar(x + i*width, prices, width, label=scenario, alpha=0.8)
    
    ax1.set_xlabel('座席类型', fontsize=11)
    ax1.set_ylabel('最优票价（元）', fontsize=11)
    ax1.set_title('成渝中线高铁最优定价（不同拉姆齐数）', fontsize=13, fontweight='bold')
    ax1.set_xticks(x + width)
    ax1.set_xticklabels(seats)
    ax1.legend()
    ax1.grid(axis='y', alpha=0.3)
    
    ax2 = axes[0, 1]
    
    seat_tiers = tiered_pricing[tiered_pricing['分层类型'] == '座席等级']
    colors = ['#3498db', '#2ecc71', '#f39c12']
    
    bars = ax2.bar(range(len(seat_tiers)), seat_tiers['票价'],
                   color=colors, alpha=0.7, edgecolor='black')
    ax2.set_xticks(range(len(seat_tiers)))
    ax2.set_xticklabels(seat_tiers['层级名称'])
    ax2.set_ylabel('票价（元）', fontsize=11)
    ax2.set_title('座席等级分层定价（成渝中线）', fontsize=13, fontweight='bold')
    ax2.grid(axis='y', alpha=0.3)
    
    for bar, price in zip(bars, seat_tiers['票价']):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height,
                f'{price:.0f}元',
                ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax3 = axes[1, 0]
    
    time_tiers = tiered_pricing[tiered_pricing['分层类型'] == '时段需求']
    colors_time = ['#e74c3c', '#3498db', '#9b59b6']
    
    bars = ax3.bar(range(len(time_tiers)), time_tiers['票价'],
                   color=colors_time, alpha=0.7, edgecolor='black')
    ax3.set_xticks(range(len(time_tiers)))
    ax3.set_xticklabels(time_tiers['层级名称'])
    ax3.set_ylabel('票价（元）', fontsize=11)
    ax3.set_title('时段需求分层定价（二等座）', fontsize=13, fontweight='bold')
    ax3.grid(axis='y', alpha=0.3)
    
    for bar, price in zip(bars, time_tiers['票价']):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height,
                f'{price:.0f}元',
                ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax4 = axes[1, 1]
    
    balanced = results_df[results_df['定价情景'] == '平衡导向']
    
    ax4.scatter(balanced['Q值'], balanced['最优票价'],
                s=150, alpha=0.6, edgecolors='black', c='#3498db')
    
    z = np.polyfit(balanced['Q值'], balanced['最优票价'], 1)
    p = np.poly1d(z)
    x_line = np.linspace(balanced['Q值'].min(), balanced['Q值'].max(), 100)
    ax4.plot(x_line, p(x_line), "r--", linewidth=2,
             label=f'拟合线: P = {z[0]:.1f}Q + {z[1]:.1f}')
    
    for idx, row in balanced.iterrows():
        ax4.annotate(row['座席'], (row['Q值'], row['最优票价']),
                    fontsize=8, ha='center', xytext=(5, 5),
                    textcoords='offset points')
    
    ax4.set_xlabel('服务质量Q值', fontsize=11)
    ax4.set_ylabel('最优票价（元）', fontsize=11)
    ax4.set_title('服务质量Q值与最优票价的关系', fontsize=13, fontweight='bold')
    ax4.legend()
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('改进版_拉姆齐定价可视化.png', dpi=300, bbox_inches='tight')
    print("\n可视化图表已保存: 改进版_拉姆齐定价可视化.png")


if __name__ == "__main__":
    results_df, tiered_pricing = improved_ramsey_pricing()
    print("\n改进版拉姆齐定价分析完成！")
