import requests
from bs4 import BeautifulSoup
import time
import csv

# 配置项（可根据需要调整）
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.ctrip.com/",
    "Cookie": ""  # 可选：登录携程后复制浏览器Cookie，填入可爬取更多内容
}
BASE_URL = "https://you.ctrip.com/travels/chongqing158/5815956.html"  # 成渝线路评论页示例（需替换为实际链接）
DELAY = 2  # 每次请求延时2秒，避免反爬
SAVE_PATH = "chengdu_chongqing_comments.csv"  # 评论保存路径

def get_comments(url):
    """
    爬取单页评论
    :param url: 携程评论页URL
    :return: 评论列表（包含用户名、时间、内容、评分）
    """
    comments = []
    try:
        # 发送请求（加超时保护）
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status()  # 抛出HTTP错误
        response.encoding = "utf-8"  # 统一编码
        
        # 解析网页
        soup = BeautifulSoup(response.text, "html.parser")
        
        # 定位评论区块（需根据实际页面结构调整Selector）
        comment_blocks = soup.find_all("div", class_="comment-item")  # 示例类名，需按实际页面修改
        
        for block in comment_blocks:
            # 提取评论信息（容错处理，避免字段缺失报错）
            username = block.find("span", class_="user-name")
            username = username.text.strip() if username else "匿名用户"
            
            comment_time = block.find("span", class_="comment-time")
            comment_time = comment_time.text.strip() if comment_time else "未知时间"
            
            comment_content = block.find("div", class_="comment-content")
            comment_content = comment_content.text.strip() if comment_content else "无内容"
            
            comment_score = block.find("span", class_="comment-score")
            comment_score = comment_score.text.strip() if comment_score else "无评分"
            
            # 整理数据
            comments.append({
                "用户名": username,
                "评论时间": comment_time,
                "评论内容": comment_content,
                "评分": comment_score
            })
        
        print(f"成功爬取 {len(comments)} 条评论")
        return comments
    
    except Exception as e:
        print(f"爬取失败：{str(e)}")
        return []

def save_comments(comments, path):
    """
    将评论保存为CSV文件（便于后续LLM处理）
    :param comments: 评论列表
    :param path: 保存路径
    """
    if not comments:
        print("无评论数据可保存")
        return
    
    # 写入CSV
    with open(path, "w", newline="", encoding="utf-8") as f:
        fieldnames = ["用户名", "评论时间", "评论内容", "评分"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(comments)
    
    print(f"评论已保存至：{path}")

if __name__ == "__main__":
    # 主流程：爬取→保存
    print("开始爬取携程成渝线路评论...")
    time.sleep(DELAY)  # 初始延时
    comments = get_comments(BASE_URL)
    save_comments(comments, SAVE_PATH)
    print("爬取完成！")