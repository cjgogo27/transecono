import requests
from bs4 import BeautifulSoup
import time
import csv

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.ctrip.com/",
    "Cookie": "" 
}
BASE_URL = "https://you.ctrip.com/travels/chongqing158/5815956.html" 
DELAY = 2 
SAVE_PATH = "chengdu_chongqing_comments.csv" 

def get_comments(url):
    comments = []
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status()  
        response.encoding = "utf-8" 
        
        soup = BeautifulSoup(response.text, "html.parser")
        
        comment_blocks = soup.find_all("div", class_="comment-item") 
        
        for block in comment_blocks:
            username = block.find("span", class_="user-name")
            username = username.text.strip() if username else "匿名用户"
            
            comment_time = block.find("span", class_="comment-time")
            comment_time = comment_time.text.strip() if comment_time else "未知时间"
            
            comment_content = block.find("div", class_="comment-content")
            comment_content = comment_content.text.strip() if comment_content else "无内容"
            
            comment_score = block.find("span", class_="comment-score")
            comment_score = comment_score.text.strip() if comment_score else "无评分"
            
            comments.append({
                "用户名": username,
                "评论时间": comment_time,
                "评论内容": comment_content,
                "评分": comment_score
            })
        
        print(f"成功爬取 {len(comments)} 条评论")
        return comments
    
    except Exception as e:
        print(f"爬取失败：{str(e)}")
        return []

def save_comments(comments, path):
    if not comments:
        print("无评论数据可保存")
        return
    
    with open(path, "w", newline="", encoding="utf-8") as f:
        fieldnames = ["用户名", "评论时间", "评论内容", "评分"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(comments)
    
    print(f"评论已保存至：{path}")

if __name__ == "__main__":
    print("开始爬取携程成渝线路评论...")
    time.sleep(DELAY) 
    comments = get_comments(BASE_URL)
    save_comments(comments, SAVE_PATH)
    print("爬取完成！")