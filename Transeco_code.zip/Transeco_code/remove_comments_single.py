import re

def remove_all_comments(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    lines = content.split('\n')
    cleaned_lines = []
    in_multiline_comment = False
    quote_type = None
    
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.lstrip()
        
        if not in_multiline_comment:
            if stripped.startswith('"""') or stripped.startswith("'''"):
                quote_type = '"""' if stripped.startswith('"""') else "'''"
                if stripped.count(quote_type) >= 2:
                    i += 1
                    continue
                else:
                    in_multiline_comment = True
                    i += 1
                    continue
            elif not stripped.startswith('#'):
                cleaned_lines.append(line)
        else:
            if quote_type in line:
                in_multiline_comment = False
                quote_type = None
        
        i += 1
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(cleaned_lines))
    
    print(f'已处理: {file_path}')

remove_all_comments('e:/Transeco_code/config.py')
print('config.py 的注释已去除！')
