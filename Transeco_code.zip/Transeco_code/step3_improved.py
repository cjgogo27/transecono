
import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import matplotlib.pyplot as plt
import json

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def estimate_improved_logit():
    
    df = pd.read_csv("改进版_离散选择数据集.csv", encoding='utf-8-sig')
    
    print("=== 标准Logit离散选择模型估计 ===\n")
    
    
    actual_choices = df[df['是否选择Y'] == 1].copy()
    
    print(f"样本量: {len(actual_choices)}")
    print(f"选择分布:")
    print(actual_choices['座席类型'].value_counts())
    print()
    
    print("【模型1：价格-Q值简化模型】")
    print("模型: P(选择) = f(票价, Q值)")
    print()
    
    actual_choices['选高价座席'] = actual_choices['座席类型'].apply(
        lambda x: 1 if x in ['一等座', '商务座'] else 0
    )
    
    X1 = actual_choices[['票价P', 'Q值']]
    y1 = actual_choices['选高价座席']
    
    X1 = sm.add_constant(X1)
    
    model1 = sm.Logit(y1, X1)
    result1 = model1.fit(disp=0, maxiter=100)
    
    print(result1.summary())
    print("\n")
    
    print("【模型2：完整离散选择模型】")
    print("模型: U = β₀ + β_P·价格 + β_T·耗时 + β_Q·Q值")
    print()
    
    
    df_二等座 = df[df['座席类型'] == '二等座'].copy()
    
    baseline = df_二等座.groupby('旅客ID').first()[['票价P', '耗时T', 'Q值']].reset_index()
    baseline.columns = ['旅客ID', '基准票价', '基准耗时', '基准Q值']
    
    df_with_baseline = df.merge(baseline, on='旅客ID')
    
    df_with_baseline['相对票价'] = df_with_baseline['票价P'] - df_with_baseline['基准票价']
    df_with_baseline['相对耗时'] = df_with_baseline['耗时T'] - df_with_baseline['基准耗时']
    df_with_baseline['相对Q值'] = df_with_baseline['Q值'] - df_with_baseline['基准Q值']
    
    df_relative = df_with_baseline[df_with_baseline['座席类型'] != '二等座'].copy()
    
    X2 = df_relative[['相对票价', '相对耗时', '相对Q值']]
    y2 = df_relative['是否选择Y']
    
    X2 = sm.add_constant(X2)
    
    model2 = sm.Logit(y2, X2)
    result2 = model2.fit(disp=0, maxiter=100, method='bfgs')
    
    print(result2.summary())
    print("\n")
    
    print("=== 关键经济学指标 ===\n")
    
    beta_p = result2.params['相对票价']
    beta_t = result2.params['相对耗时']
    beta_q = result2.params['相对Q值']
    
    print(f"β_P (价格系数): {beta_p:.4f}")
    print(f"β_T (时间系数): {beta_t:.4f}")
    print(f"β_Q (Q值系数): {beta_q:.4f}")
    print()
    
    if abs(beta_p) > 0.001:
        value_of_q = -beta_q / beta_p
        value_of_time = -beta_t / beta_p * 60  # 转换为元/小时
        
        print(f"✓ 服务质量货币价值: {value_of_q:.2f} 元/分")
        print(f"  → Q值每提高1分，旅客愿意多支付 {value_of_q:.2f} 元")
        print()
        print(f"✓ 时间价值: {value_of_time:.2f} 元/小时")
        print(f"  → 耗时每减少1小时，旅客愿意多支付 {value_of_time:.2f} 元")
        print()
    else:
        print("警告：价格系数接近0，无法计算货币价值")
        value_of_q = 0
        value_of_time = 0
    
    print("=== 参数显著性检验 ===")
    for param in ['相对票价', '相对耗时', '相对Q值']:
        p_value = result2.pvalues[param]
        significance = "***" if p_value < 0.01 else ("**" if p_value < 0.05 else ("*" if p_value < 0.1 else "不显著"))
        print(f"{param:10s}: p值 = {p_value:.4f} {significance}")
    print()
    
    print("=== 模型拟合优度 ===")
    print(f"对数似然值: {result2.llf:.2f}")
    print(f"Pseudo R²: {result2.prsquared:.4f}")
    print(f"AIC: {result2.aic:.2f}")
    print()
    
    model_results = {
        'β_P': float(beta_p),
        'β_T': float(beta_t),
        'β_Q': float(beta_q),
        'value_of_Q': float(value_of_q),
        'value_of_time': float(value_of_time),
        'log_likelihood': float(result2.llf),
        'pseudo_R2': float(result2.prsquared),
        'p_value_price': float(result2.pvalues['相对票价']),
        'p_value_time': float(result2.pvalues['相对耗时']),
        'p_value_q': float(result2.pvalues['相对Q值']),
    }
    
    with open('改进版_模型估计结果.json', 'w', encoding='utf-8') as f:
        json.dump(model_results, f, indent=2, ensure_ascii=False)
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1 = axes[0]
    params = ['票价', '耗时', 'Q值']
    values = [beta_p, beta_t, beta_q]
    colors = ['#e74c3c' if v < 0 else '#2ecc71' for v in values]
    
    bars = ax1.barh(params, values, color=colors, alpha=0.7, edgecolor='black')
    ax1.set_xlabel('系数值', fontsize=12)
    ax1.set_title('Logit模型系数估计结果', fontsize=14, fontweight='bold')
    ax1.axvline(x=0, color='black', linestyle='--', linewidth=1)
    ax1.grid(axis='x', alpha=0.3)
    
    for bar, val in zip(bars, values):
        width = bar.get_width()
        ax1.text(width, bar.get_y() + bar.get_height()/2.,
                f'{val:.3f}',
                ha='left' if width > 0 else 'right',
                va='center', fontweight='bold')
    
    ax2 = axes[1]
    metrics = [f'Q值价值\n({value_of_q:.1f}元/分)', 
               f'时间价值\n({value_of_time:.1f}元/小时)']
    metric_values = [value_of_q, value_of_time]
    
    bars2 = ax2.bar(range(len(metrics)), metric_values, 
                    color=['#3498db', '#f39c12'], alpha=0.7, edgecolor='black')
    ax2.set_xticks(range(len(metrics)))
    ax2.set_xticklabels(metrics, fontsize=10)
    ax2.set_ylabel('货币价值（元）', fontsize=12)
    ax2.set_title('服务质量与时间的货币价值', fontsize=14, fontweight='bold')
    ax2.grid(axis='y', alpha=0.3)
    
    for bar, val in zip(bars2, metric_values):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height,
                f'{val:.1f}',
                ha='center', va='bottom', fontsize=11, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('改进版_模型系数可视化.png', dpi=300, bbox_inches='tight')
    print("可视化图表已保存: 改进版_模型系数可视化.png\n")
    
    return result1, result2, model_results


if __name__ == "__main__":
    result1, result2, model_results = estimate_improved_logit()
    print("\n改进版Logit模型估计完成！")
