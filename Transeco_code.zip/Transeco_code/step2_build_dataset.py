"""
第二步：构建离散选择模型的完整数据集
需要包含：因变量Y（旅客选择）、自变量P（票价）、T（耗时）、Q（综合评分）
"""

import pandas as pd
import numpy as np

def build_choice_dataset():
    """
    构建离散选择模型的数据集
    
    这里需要构造不同交通方式的对比数据：
    - 成渝高铁（老线）
    - 成渝中线高铁（新线，假设）
    - 普速列车
    - 大巴
    
    每个旅客的选择记录包含所有可选方案的属性
    """
    
    # 读取带评分的评论数据
    comments_df = pd.read_csv("用户评价_带评分.csv", encoding='utf-8-sig')
    
    # 计算各交通方式的平均Q值（基于评论数据）
    avg_q_value = comments_df['综合Q值'].mean()
    
    print(f"基于评论数据，高铁平均Q值: {avg_q_value:.2f}")
    
    # 定义不同交通方式的属性
    # 数据来源：实际调研或公开数据
    transport_options = {
        "成渝高铁_老线": {
            "票价": 154,  # 二等座价格（元）
            "耗时": 1.5,  # 小时
            "Q值": avg_q_value,  # 基于实际评论
            "方式代码": 1
        },
        "成渝中线_新线": {
            "票价": 180,  # 预计价格（元）- 新线更快更好
            "耗时": 1.0,  # 小时 - 更短
            "Q值": avg_q_value + 0.8,  # 假设新线服务质量更好
            "方式代码": 2
        },
        "成渝高铁_一等座": {
            "票价": 247,  # 一等座价格
            "耗时": 1.5,
            "Q值": avg_q_value + 0.5,  # 一等座舒适度更高
            "方式代码": 3
        },
        "普速列车": {
            "票价": 65,  # 普通列车价格
            "耗时": 4.0,  # 小时
            "Q值": avg_q_value - 1.2,  # 服务质量较低
            "方式代码": 4
        },
        "大巴": {
            "票价": 80,  # 大巴价格
            "耗时": 3.5,  # 小时
            "Q值": avg_q_value - 1.5,  # 服务质量最低
            "方式代码": 5
        }
    }
    
    # 构建选择数据集（长格式 - Long Format）
    # 每个旅客面对多个选择，最终选择其中一个
    
    choice_data = []
    individual_id = 1
    
    # 模拟不同旅客群体的选择行为
    # 这里我们根据评论数据中的出行场景来构建
    
    scenarios = comments_df['出行场景'].value_counts()
    
    for scenario, count in scenarios.items():
        # 为每个场景生成多个旅客选择记录
        for i in range(count * 10):  # 扩充样本量
            # 每个旅客看到所有5种交通方式
            for transport, attrs in transport_options.items():
                # 根据场景和个人特征模拟选择
                # 这里需要基于实际调研数据，目前使用合理假设
                
                # 判断该旅客是否选择了这种方式（因变量Y）
                chosen = 0
                
                # 商务通勤：倾向于高铁（快速、高频）
                if scenario == "商务通勤":
                    if transport in ["成渝高铁_老线", "成渝中线_新线"]:
                        chosen = np.random.choice([0, 1], p=[0.2, 0.8])
                    elif transport == "成渝高铁_一等座":
                        chosen = np.random.choice([0, 1], p=[0.7, 0.3])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.95, 0.05])
                
                # 周末旅游/短途旅游：价格敏感，但也看重舒适度
                elif scenario in ["周末旅游", "短途旅游", "旅游出行"]:
                    if transport == "成渝高铁_老线":
                        chosen = np.random.choice([0, 1], p=[0.3, 0.7])
                    elif transport == "成渝中线_新线":
                        chosen = np.random.choice([0, 1], p=[0.6, 0.4])
                    elif transport == "普速列车":
                        chosen = np.random.choice([0, 1], p=[0.8, 0.2])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.9, 0.1])
                
                # 双城探亲/恋爱通勤：平衡价格和舒适度
                elif scenario in ["双城探亲", "双城恋爱通勤"]:
                    if transport == "成渝高铁_老线":
                        chosen = np.random.choice([0, 1], p=[0.25, 0.75])
                    elif transport == "成渝中线_新线":
                        chosen = np.random.choice([0, 1], p=[0.5, 0.5])
                    elif transport == "大巴":
                        chosen = np.random.choice([0, 1], p=[0.85, 0.15])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.9, 0.1])
                
                else:
                    # 默认情况
                    if transport == "成渝高铁_老线":
                        chosen = np.random.choice([0, 1], p=[0.4, 0.6])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.8, 0.2])
                
                # 添加时间价值（元/小时）
                # 不同场景的旅客时间价值不同
                if scenario == "商务通勤":
                    time_value = np.random.normal(80, 15)  # 商务旅客时间价值高
                elif scenario in ["双城探亲", "双城恋爱通勤"]:
                    time_value = np.random.normal(50, 10)
                else:
                    time_value = np.random.normal(35, 8)  # 旅游旅客时间价值较低
                
                choice_data.append({
                    "旅客ID": individual_id,
                    "出行场景": scenario,
                    "交通方式": transport,
                    "方式代码": attrs["方式代码"],
                    "票价P": attrs["票价"],
                    "耗时T": attrs["耗时"],
                    "综合Q值": attrs["Q值"],
                    "时间价值": max(20, time_value),  # 确保时间价值为正
                    "广义成本": attrs["票价"] + max(20, time_value) * attrs["耗时"],
                    "是否选择Y": chosen
                })
            
            individual_id += 1
    
    # 转换为DataFrame
    choice_df = pd.DataFrame(choice_data)
    
    # 确保每个旅客只选择一种方式
    # 对于每个旅客ID，如果没有选择任何方式，随机选择一个
    for pid in choice_df['旅客ID'].unique():
        person_choices = choice_df[choice_df['旅客ID'] == pid]
        if person_choices['是否选择Y'].sum() == 0:
            # 随机选择一个
            random_choice_idx = np.random.choice(person_choices.index)
            choice_df.loc[random_choice_idx, '是否选择Y'] = 1
        elif person_choices['是否选择Y'].sum() > 1:
            # 如果选择了多个，只保留第一个
            chosen_indices = person_choices[person_choices['是否选择Y'] == 1].index
            choice_df.loc[chosen_indices[1:], '是否选择Y'] = 0
    
    # 保存数据集
    choice_df.to_csv("离散选择数据集.csv", index=False, encoding='utf-8-sig')
    
    print(f"\n数据集构建完成！")
    print(f"总样本数: {len(choice_df)}")
    print(f"旅客人数: {choice_df['旅客ID'].nunique()}")
    print(f"\n各交通方式选择比例:")
    print(choice_df[choice_df['是否选择Y'] == 1]['交通方式'].value_counts(normalize=True))
    
    # 统计信息
    print(f"\n=== 数据集统计 ===")
    print(choice_df.groupby('交通方式')[['票价P', '耗时T', '综合Q值', '广义成本']].mean())
    
    return choice_df


if __name__ == "__main__":
    choice_df = build_choice_dataset()
    print("\n第二步完成！离散选择数据集已构建。")
