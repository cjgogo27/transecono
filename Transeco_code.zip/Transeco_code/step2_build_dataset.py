
import pandas as pd
import numpy as np

def build_choice_dataset():
  
    comments_df = pd.read_csv("用户评价_带评分.csv", encoding='utf-8-sig')
    
    avg_q_value = comments_df['综合Q值'].mean()
    
    print(f"基于评论数据，高铁平均Q值: {avg_q_value:.2f}")

    transport_options = {
        "成渝高铁_老线": {
            "票价": 154, 
            "耗时": 1.5, 
            "Q值": avg_q_value,  
            "方式代码": 1
        },
        "成渝中线_新线": {
            "票价": 180, 
            "耗时": 1.0,  
            "Q值": avg_q_value + 0.8,  
            "方式代码": 2
        },
        "成渝高铁_一等座": {
            "票价": 247,  
            "耗时": 1.5,
            "Q值": avg_q_value + 0.5,  
            "方式代码": 3
        },
        "普速列车": {
            "票价": 65,  
            "耗时": 4.0,  
            "Q值": avg_q_value - 1.2,  
            "方式代码": 4
        },
        "大巴": {
            "票价": 80,  
            "耗时": 3.5,  
            "Q值": avg_q_value - 1.5,  
            "方式代码": 5
        }
    }
    
    choice_data = []
    individual_id = 1
    
    scenarios = comments_df['出行场景'].value_counts()
    
    for scenario, count in scenarios.items():
        for i in range(count * 10): 
            for transport, attrs in transport_options.items():
                
                chosen = 0

                if scenario == "商务通勤":
                    if transport in ["成渝高铁_老线", "成渝中线_新线"]:
                        chosen = np.random.choice([0, 1], p=[0.2, 0.8])
                    elif transport == "成渝高铁_一等座":
                        chosen = np.random.choice([0, 1], p=[0.7, 0.3])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.95, 0.05])

                elif scenario in ["周末旅游", "短途旅游", "旅游出行"]:
                    if transport == "成渝高铁_老线":
                        chosen = np.random.choice([0, 1], p=[0.3, 0.7])
                    elif transport == "成渝中线_新线":
                        chosen = np.random.choice([0, 1], p=[0.6, 0.4])
                    elif transport == "普速列车":
                        chosen = np.random.choice([0, 1], p=[0.8, 0.2])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.9, 0.1])

                elif scenario in ["双城探亲", "双城恋爱通勤"]:
                    if transport == "成渝高铁_老线":
                        chosen = np.random.choice([0, 1], p=[0.25, 0.75])
                    elif transport == "成渝中线_新线":
                        chosen = np.random.choice([0, 1], p=[0.5, 0.5])
                    elif transport == "大巴":
                        chosen = np.random.choice([0, 1], p=[0.85, 0.15])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.9, 0.1])
                
                else:
                    if transport == "成渝高铁_老线":
                        chosen = np.random.choice([0, 1], p=[0.4, 0.6])
                    else:
                        chosen = np.random.choice([0, 1], p=[0.8, 0.2])

                if scenario == "商务通勤":
                    time_value = np.random.normal(80, 15) 
                elif scenario in ["双城探亲", "双城恋爱通勤"]:
                    time_value = np.random.normal(50, 10)
                else:
                    time_value = np.random.normal(35, 8)  
                choice_data.append({
                    "旅客ID": individual_id,
                    "出行场景": scenario,
                    "交通方式": transport,
                    "方式代码": attrs["方式代码"],
                    "票价P": attrs["票价"],
                    "耗时T": attrs["耗时"],
                    "综合Q值": attrs["Q值"],
                    "时间价值": max(20, time_value),  
                    "广义成本": attrs["票价"] + max(20, time_value) * attrs["耗时"],
                    "是否选择Y": chosen
                })
            
            individual_id += 1
    
    choice_df = pd.DataFrame(choice_data)

    for pid in choice_df['旅客ID'].unique():
        person_choices = choice_df[choice_df['旅客ID'] == pid]
        if person_choices['是否选择Y'].sum() == 0:
            random_choice_idx = np.random.choice(person_choices.index)
            choice_df.loc[random_choice_idx, '是否选择Y'] = 1
        elif person_choices['是否选择Y'].sum() > 1:
            chosen_indices = person_choices[person_choices['是否选择Y'] == 1].index
            choice_df.loc[chosen_indices[1:], '是否选择Y'] = 0
    
    choice_df.to_csv("离散选择数据集.csv", index=False, encoding='utf-8-sig')

    print(f"\n=== 数据集统计 ===")
    print(choice_df.groupby('交通方式')[['票价P', '耗时T', '综合Q值', '广义成本']].mean())
    
    return choice_df


if __name__ == "__main__":
    choice_df = build_choice_dataset()
