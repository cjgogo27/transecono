
import sys
from datetime import datetime

def main():
    
    try:
        print("第一步：使用LLM分析评论数据")
        
        import pandas as pd
        comments_df = pd.read_csv('用户评价_带评分.csv', encoding='utf-8-sig')
        
        input("按Enter键继续...")
        
        print("第二步：构建改进的选择数据集")

        
        from step2_improved import build_improved_dataset
        choice_df = build_improved_dataset()
   
        
        input("按Enter键继续...")
        
        print("第三步：标准Logit离散选择模型估计")
        
        from step3_improved import estimate_improved_logit
        result1, result2, model_results = estimate_improved_logit()
        
        input("按Enter键继续...")
        
        print("第五步：标准拉姆齐定价模型")
        
        from step5_improved import improved_ramsey_pricing
        results_df, tiered_pricing = improved_ramsey_pricing()

        import os
        import json
        
        output_files = [
            ('改进版_离散选择数据集.csv', '改进的选择数据'),
            ('改进版_模型估计结果.json', 'Logit模型参数'),
            ('改进版_模型系数可视化.png', '模型系数图表'),
            ('改进版_拉姆齐定价结果.csv', '最优定价结果'),
            ('改进版_分层定价方案.csv', '分层定价方案'),
            ('改进版_拉姆齐定价可视化.png', '定价方案图表'),
        ]
        
        for i, (filename, description) in enumerate(output_files, 1):
            status = "✓" if os.path.exists(filename) else "✗"
            print(f"{status} {i}. {filename:40s} - {description}")
        
        
        with open('改进版_模型估计结果.json', 'r', encoding='utf-8') as f:
            model_res = json.load(f)
        
        pricing_final = pd.read_csv('改进版_拉姆齐定价结果.csv', encoding='utf-8-sig')
        balanced = pricing_final[pricing_final['定价情景'] == '平衡导向']
        
        print(f"\n3. 成渝中线定价建议（平衡导向，λ=0.35）：")
        new_line = balanced[balanced['线路'] == '成渝中线']
        for idx, row in new_line.iterrows():
            print(f"   {row['座席']:8s}: {row['最优票价']:6.1f}元 "
                  f"(当前{row['当前票价']:.0f}元, 调整{row['调整幅度%']:+.1f}%)")
        
        tiers = pd.read_csv('改进版_分层定价方案.csv', encoding='utf-8-sig')
        seat_tiers = tiers[tiers['分层类型'] == '座席等级']
        time_tiers = tiers[tiers['分层类型'] == '时段需求']
        
    except Exception as e:
        print(f"\n错误：{str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
